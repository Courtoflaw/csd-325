def get_formatted_location(city, state):
    """Generate a neatly formatted location data."""
    location_data = f"{city} {state}"
    return location_data.title()