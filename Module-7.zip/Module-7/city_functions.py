def get_formatted_location(city, country, population='', language=''):
    """Generate a neatly formatted location data."""
    if population:
        location_data = f"{city} {country} {population}"
    if language:
        location_data = f"{city} {country} {population} {language}"
    else: 
        location_data = f"{city} {country}"
    return location_data.title()