import unittest

from city_functions import get_formatted_location
def test_cities():
      """Do entries like 'dacrib hometown' work?"""
formatted_location = get_formatted_location('dacrib', 'hometown')
assert formatted_location == 'Dacrib Hometown'