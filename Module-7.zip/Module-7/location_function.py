def get_formatted_location(city, state, population, language):
    """Generate a neatly formatted location data."""
    location_data = f"{city} {state} {population}{language}"
    return location_data.title()