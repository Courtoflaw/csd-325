from city_functions import get_formatted_location

print("Enter 'q' at any time to quit.")
while True:
    city = input("\nWhich city do you currently reside?: ")
    if city == 'q':
        break
    country = input("Please enter your Country: ")
    if country == 'q':
        break
    population = input("\nWhat is the population where you live?: ")
    if population == 'q':
        break
    language = input("\nWhich language do you speak?: ")
    if language == 'q':
        break	
    formatted_location = get_formatted_location(city, country, population, language)
    print(f"\tNeatly formatted location: {formatted_location}.")
    
