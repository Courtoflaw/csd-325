def main():

  intro()

  try:

   miles_driven = int(input('Please enter the number of miles you have driven : '))
  
   miles_to_km(miles_driven)

  except:
    print("Only numbers work, try again...")
    print()
    main()


def intro():
  print('Hi! I convert miles ')
  print('to kilometers. For your')
  print('reference the formula is: ')
  print('1 mile = 1.609344 kilometers')
  print()


def miles_to_km(miles):
 kilometers = miles * 1.609344
 miles = round(kilometers / 1.609344)
 print( miles,' miles converts to'), print(kilometers,  'kilometers')

main()
print('Thanks for your input!')