import requests

import json

response = requests.get('http://api.artic.edu/api/v1/artworks')
print(response.status_code)

def jprint(obj):
    text = json.dumps(obj, sort_keys=True, indent=4)
    print(text)

jprint(response.json())